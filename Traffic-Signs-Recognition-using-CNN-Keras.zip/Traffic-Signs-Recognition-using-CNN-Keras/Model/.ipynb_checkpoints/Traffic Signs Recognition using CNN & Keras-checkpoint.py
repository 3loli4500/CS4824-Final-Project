{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Traffic Signs Recognition using CNN & Keras"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "In this Python project example, we will build a deep neural network model that can classify traffic signs present in the image into different categories. With this model, we are able to read and understand traffic signs which are a very important task for all autonomous vehicles."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Our approach to building this traffic sign classification model is discussed in four steps:\n",
    "\n",
    "- Explore the dataset\n",
    "- Build a CNN model\n",
    "- Train and validate the model\n",
    "- Test the model with test dataset"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: tensorflow in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (2.16.1)\n",
      "Requirement already satisfied: keras in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (3.2.1)\n",
      "Requirement already satisfied: scikit-learn in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (1.4.2)\n",
      "Requirement already satisfied: matplotlib in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (3.8.2)\n",
      "Requirement already satisfied: pandas in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (2.2.2)\n",
      "Requirement already satisfied: pillow in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (10.2.0)\n",
      "Requirement already satisfied: tensorflow-intel==2.16.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow) (2.16.1)\n",
      "Requirement already satisfied: absl-py>=1.0.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.1.0)\n",
      "Requirement already satisfied: astunparse>=1.6.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.6.3)\n",
      "Requirement already satisfied: flatbuffers>=23.5.26 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (24.3.25)\n",
      "Requirement already satisfied: gast!=0.5.0,!=0.5.1,!=0.5.2,>=0.2.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.5.4)\n",
      "Requirement already satisfied: google-pasta>=0.1.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.2.0)\n",
      "Requirement already satisfied: h5py>=3.10.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (3.11.0)\n",
      "Requirement already satisfied: libclang>=13.0.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (18.1.1)\n",
      "Requirement already satisfied: ml-dtypes~=0.3.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (0.3.2)\n",
      "Requirement already satisfied: opt-einsum>=2.3.2 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (3.3.0)\n",
      "Requirement already satisfied: packaging in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (23.2)\n",
      "Requirement already satisfied: protobuf!=4.21.0,!=4.21.1,!=4.21.2,!=4.21.3,!=4.21.4,!=4.21.5,<5.0.0dev,>=3.20.3 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (4.25.3)\n",
      "Requirement already satisfied: requests<3,>=2.21.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.31.0)\n",
      "Requirement already satisfied: setuptools in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (69.5.1)\n",
      "Requirement already satisfied: six>=1.12.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.16.0)\n",
      "Requirement already satisfied: termcolor>=1.1.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.4.0)\n",
      "Requirement already satisfied: typing-extensions>=3.6.6 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (4.11.0)\n",
      "Requirement already satisfied: wrapt>=1.11.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.16.0)\n",
      "Requirement already satisfied: grpcio<2.0,>=1.24.3 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.62.1)\n",
      "Requirement already satisfied: tensorboard<2.17,>=2.16 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (2.16.2)\n",
      "Requirement already satisfied: numpy<2.0.0,>=1.26.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorflow-intel==2.16.1->tensorflow) (1.26.4)\n",
      "Requirement already satisfied: rich in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from keras) (13.7.1)\n",
      "Requirement already satisfied: namex in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from keras) (0.0.8)\n",
      "Requirement already satisfied: optree in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from keras) (0.11.0)\n",
      "Requirement already satisfied: scipy>=1.6.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from scikit-learn) (1.13.0)\n",
      "Requirement already satisfied: joblib>=1.2.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from scikit-learn) (1.4.0)\n",
      "Requirement already satisfied: threadpoolctl>=2.0.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from scikit-learn) (3.4.0)\n",
      "Requirement already satisfied: contourpy>=1.0.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from matplotlib) (1.2.0)\n",
      "Requirement already satisfied: cycler>=0.10 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from matplotlib) (0.12.1)\n",
      "Requirement already satisfied: fonttools>=4.22.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from matplotlib) (4.48.1)\n",
      "Requirement already satisfied: kiwisolver>=1.3.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from matplotlib) (1.4.5)\n",
      "Requirement already satisfied: pyparsing>=2.3.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from matplotlib) (3.1.1)\n",
      "Requirement already satisfied: python-dateutil>=2.7 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from matplotlib) (2.8.2)\n",
      "Requirement already satisfied: pytz>=2020.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from pandas) (2024.1)\n",
      "Requirement already satisfied: tzdata>=2022.7 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from pandas) (2024.1)\n",
      "Requirement already satisfied: markdown-it-py>=2.2.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from rich->keras) (3.0.0)\n",
      "Requirement already satisfied: pygments<3.0.0,>=2.13.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from rich->keras) (2.17.2)\n",
      "Requirement already satisfied: wheel<1.0,>=0.23.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from astunparse>=1.6.0->tensorflow-intel==2.16.1->tensorflow) (0.43.0)\n",
      "Requirement already satisfied: mdurl~=0.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from markdown-it-py>=2.2.0->rich->keras) (0.1.2)\n",
      "Requirement already satisfied: charset-normalizer<4,>=2 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (3.3.2)\n",
      "Requirement already satisfied: idna<4,>=2.5 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (3.6)\n",
      "Requirement already satisfied: urllib3<3,>=1.21.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (2.2.0)\n",
      "Requirement already satisfied: certifi>=2017.4.17 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from requests<3,>=2.21.0->tensorflow-intel==2.16.1->tensorflow) (2024.2.2)\n",
      "Requirement already satisfied: markdown>=2.6.8 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (3.6)\n",
      "Requirement already satisfied: tensorboard-data-server<0.8.0,>=0.7.0 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (0.7.2)\n",
      "Requirement already satisfied: werkzeug>=1.0.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (3.0.2)\n",
      "Requirement already satisfied: MarkupSafe>=2.1.1 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from werkzeug>=1.0.1->tensorboard<2.17,>=2.16->tensorflow-intel==2.16.1->tensorflow) (2.1.5)\n",
      "Requirement already satisfied: opencv-python in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (4.9.0.80)\n",
      "Requirement already satisfied: numpy>=1.21.2 in c:\\users\\dell\\appdata\\local\\programs\\python\\python312\\lib\\site-packages (from opencv-python) (1.26.4)\n"
     ]
    }
   ],
   "source": [
    "!pip install tensorflow keras scikit-learn matplotlib pandas pillow\n",
    "!pip install opencv-python"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "import numpy as np \n",
    "import pandas as pd \n",
    "import matplotlib.pyplot as plt\n",
    "import cv2\n",
    "import tensorflow as tf\n",
    "from PIL import Image\n",
    "import os\n",
    "from sklearn.model_selection import train_test_split\n",
    "from keras.utils import to_categorical\n",
    "from keras.models import Sequential, load_model\n",
    "from keras.layers import Conv2D, MaxPool2D, Dense, Flatten, Dropout"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [],
   "source": [
    "import os"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "'C:\\\\Users\\\\dell\\\\Downloads\\\\Traffic-Signs-Recognition-using-CNN-Keras\\\\Model'"
      ]
     },
     "execution_count": 4,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "os.getcwd()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {},
   "outputs": [],
   "source": [
    "#cd/Users/IRON MAN/traffic/Train\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "'C:\\\\Users\\\\dell\\\\Downloads\\\\Traffic-Signs-Recognition-using-CNN-Keras\\\\Model'"
      ]
     },
     "execution_count": 6,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "os.getcwd()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# The Dataset of Python Project\n",
    "\n",
    "For this project, we are using the public dataset available at Kaggle:\n",
    "\n",
    "[Traffic Signs Dataset](https://www.kaggle.com/meowmeowmeowmeowmeow/gtsrb-german-traffic-sign/code)\n",
    "\n",
    "The dataset contains more than 50,000 images of different traffic signs. It is further classified into 43 different classes. The dataset is quite varying, some of the classes have many images while some classes have few images. The size of the dataset is around 300 MB. The dataset has a train folder which contains images inside each class and a test folder which we will use for testing our model."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Image path: C:\\Users\\dell\\Downloads\\Traffic-Signs-Recognition-using-CNN-Keras\\Model/.ipynb_checkpoints/Traffic Signs Recognition using CNN & Keras with 98% Accuracy-checkpoint.ipynb\n",
      "Image not found or could not be read: C:\\Users\\dell\\Downloads\\Traffic-Signs-Recognition-using-CNN-Keras\\Model/.ipynb_checkpoints/Traffic Signs Recognition using CNN & Keras with 98% Accuracy-checkpoint.ipynb\n",
      "Image path: C:\\Users\\dell\\Downloads\\Traffic-Signs-Recognition-using-CNN-Keras\\Model/.ipynb_checkpoints/Traffic Signs Recognition using CNN & Keras-checkpoint.ipynb\n",
      "Image not found or could not be read: C:\\Users\\dell\\Downloads\\Traffic-Signs-Recognition-using-CNN-Keras\\Model/.ipynb_checkpoints/Traffic Signs Recognition using CNN & Keras-checkpoint.ipynb\n"
     ]
    },
    {
     "ename": "NotADirectoryError",
     "evalue": "[WinError 267] The directory name is invalid: 'C:\\\\Users\\\\dell\\\\Downloads\\\\Traffic-Signs-Recognition-using-CNN-Keras\\\\Model/Traffic Signs Recognition using CNN & Keras with 98% Accuracy.py'",
     "output_type": "error",
     "traceback": [
      "\u001b[1;31m---------------------------------------------------------------------------\u001b[0m",
      "\u001b[1;31mNotADirectoryError\u001b[0m                        Traceback (most recent call last)",
      "Cell \u001b[1;32mIn[8], line 4\u001b[0m\n\u001b[0;32m      2\u001b[0m \u001b[38;5;28;01mfor\u001b[39;00m i \u001b[38;5;129;01min\u001b[39;00m os\u001b[38;5;241m.\u001b[39mlistdir(cur_path):\n\u001b[0;32m      3\u001b[0m     \u001b[38;5;28mdir\u001b[39m \u001b[38;5;241m=\u001b[39m cur_path \u001b[38;5;241m+\u001b[39m \u001b[38;5;124m'\u001b[39m\u001b[38;5;124m/\u001b[39m\u001b[38;5;124m'\u001b[39m \u001b[38;5;241m+\u001b[39m i\n\u001b[1;32m----> 4\u001b[0m     \u001b[38;5;28;01mfor\u001b[39;00m j \u001b[38;5;129;01min\u001b[39;00m \u001b[43mos\u001b[49m\u001b[38;5;241;43m.\u001b[39;49m\u001b[43mlistdir\u001b[49m\u001b[43m(\u001b[49m\u001b[38;5;28;43mdir\u001b[39;49m\u001b[43m)\u001b[49m:\n\u001b[0;32m      5\u001b[0m         img_path \u001b[38;5;241m=\u001b[39m \u001b[38;5;28mdir\u001b[39m\u001b[38;5;241m+\u001b[39m\u001b[38;5;124m'\u001b[39m\u001b[38;5;124m/\u001b[39m\u001b[38;5;124m'\u001b[39m\u001b[38;5;241m+\u001b[39mj\n\u001b[0;32m      6\u001b[0m         \u001b[38;5;28mprint\u001b[39m(\u001b[38;5;124m\"\u001b[39m\u001b[38;5;124mImage path:\u001b[39m\u001b[38;5;124m\"\u001b[39m, img_path)\n",
      "\u001b[1;31mNotADirectoryError\u001b[0m: [WinError 267] The directory name is invalid: 'C:\\\\Users\\\\dell\\\\Downloads\\\\Traffic-Signs-Recognition-using-CNN-Keras\\\\Model/Traffic Signs Recognition using CNN & Keras with 98% Accuracy.py'"
     ]
    }
   ],
   "source": [
    "cur_path = os.getcwd()\n",
    "for i in os.listdir(cur_path):\n",
    "    dir = cur_path + '/' + i\n",
    "    for j in os.listdir(dir):\n",
    "        img_path = dir+'/'+j\n",
    "        print(\"Image path:\", img_path)\n",
    "        img = cv2.imread(img_path,-1)\n",
    "        if img is None:\n",
    "            print(\"Image not found or could not be read:\", img_path)\n",
    "            continue\n",
    "        img = cv2.resize(img, (30,30), interpolation = cv2.INTER_NEAREST)\n",
    "        data.append(img)\n",
    "        labels.append(i)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "print(data.shape, labels.shape)\n",
    "#Splitting training and testing dataset\n",
    "X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)\n",
    "print(X_train.shape, X_test.shape, y_train.shape, y_test.shape)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "#Converting the labels into one hot encoding\n",
    "y_train = to_categorical(y_train, 43)\n",
    "y_test = to_categorical(y_test, 43)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "y_train.shape, y_test.shape"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Show Datasets in CSV Formet"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "train_data=pd.read_csv('C:\\\\Users\\\\IRON MAN\\\\traffic\\\\Train.csv',usecols=['ClassId','Path','Width','Height'],)\n",
    "test_data=pd.read_csv('C:\\\\Users\\\\IRON MAN\\\\traffic\\\\Test.csv',usecols=['ClassId','Path','Width','Height'],)\n",
    "\n",
    "train_data.rename({'ClassId':'label','Path':'path'},inplace=True,axis=1)\n",
    "test_data.rename({'ClassId':'label','Path':'path'},inplace=True,axis=1)\n",
    "\n",
    "train_data.head()\n",
    "\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "test_data.head()\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "print('NO. of classes')\n",
    "print(train_data['label'].nunique())"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "cd/Users/IRON MAN/traffic"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Let's Visualize the testing Data"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "scrolled": true
   },
   "outputs": [],
   "source": [
    "import random\n",
    "from matplotlib.image import imread\n",
    "data_dir= os.getcwd()\n",
    "imgs=test_data['path'].values\n",
    "plt.figure(figsize=(25,25))\n",
    "\n",
    "for i in range(1,26):\n",
    "    plt.subplot(5,5,i)\n",
    "    random_image_path=data_dir+'/'+random.choice(imgs)\n",
    "    random_image=imread(random_image_path)\n",
    "    plt.imshow(random_image)\n",
    "    plt.grid(b=None)\n",
    "    plt.axis('off')\n",
    "    plt.xlabel(random_image.shape[0],fontsize=20)\n",
    "    plt.ylabel(random_image.shape[0],fontsize=20)\n",
    "    \n",
    "    \n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "cd/Users/IRON MAN/traffic/Train"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Let's Visualize the Training Datasets in Sorted grids formet"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "# number of images in each class\n",
    "data_dic = {}\n",
    "for folder in os.listdir(cur_path):\n",
    "    data_dic[folder] = len(os.listdir(cur_path + '/' + folder))\n",
    "\n",
    "data_df= pd.Series(data_dic)\n",
    "plt.figure(figsize = (15, 6))\n",
    "data_df.sort_values().plot(kind = 'bar')\n",
    "plt.xlabel('Classes')\n",
    "plt.ylabel('Number of images')"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Build a CNN model\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "#Building the model\n",
    "model = Sequential()\n",
    "\n",
    "# First Layer\n",
    "model.add(Conv2D(filters=32, kernel_size=(5,5), activation='relu', input_shape=X_train.shape[1:]))\n",
    "model.add(Conv2D(filters=32, kernel_size=(5,5), activation='relu'))\n",
    "model.add(MaxPool2D(pool_size=(2, 2)))\n",
    "model.add(Dropout(rate=0.25))\n",
    "\n",
    "# Second Layer \n",
    "model.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))\n",
    "model.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))\n",
    "model.add(MaxPool2D(pool_size=(2, 2)))\n",
    "model.add(Dropout(rate=0.25))\n",
    "\n",
    "\n",
    "# Dense Layer\n",
    "model.add(Flatten())\n",
    "model.add(Dense(256, activation='relu'))\n",
    "model.add(Dropout(rate=0.5))\n",
    "model.add(Dense(43, activation='softmax'))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "scrolled": true
   },
   "outputs": [],
   "source": [
    "model.summary()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "scrolled": true
   },
   "outputs": [],
   "source": [
    "!pip install visualkeras\n",
    "import visualkeras"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "visualkeras.layered_view(model)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Train and validate the model"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "#Compilation of the model\n",
    "model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])\n",
    "epochs = 20\n",
    "history = model.fit(X_train, y_train, batch_size=64, epochs=epochs, validation_data=(X_test, y_test))\n",
    "model.save(\"my_model.h5\")"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Plotting graphs for accuracy "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "#plotting graphs for accuracy \n",
    "plt.plot(history.history['accuracy'], label='training accuracy')\n",
    "plt.plot(history.history['val_accuracy'], label='val accuracy')\n",
    "plt.title('Accuracy')\n",
    "plt.xlabel('epochs')\n",
    "plt.ylabel('accuracy')\n",
    "plt.legend()\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "\n",
    "plt.plot(history.history['loss'], label='training loss')\n",
    "plt.plot(history.history['val_loss'], label='val loss')\n",
    "plt.title('Loss')\n",
    "plt.xlabel('epochs')\n",
    "plt.ylabel('loss')\n",
    "plt.legend()\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Evalution\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "# Score\n",
    "score = model.evaluate(X_test, y_test, verbose=0)\n",
    "print('Test Loss', score[0])\n",
    "print('Test accuracy', score[1])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "y_pred = model.predict(X_test)\n",
    "y_test_class = np.argmax(y_test,axis=1)\n",
    "y_pred_class = np.argmax(y_pred,axis=1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "\n",
    "from sklearn.metrics import classification_report\n",
    "from sklearn.metrics import classification_report,confusion_matrix\n",
    "print(classification_report(y_test_class,y_pred_class))\n",
    "print(confusion_matrix(y_test_class,y_pred_class))"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "# Making the Confusion Matrix\n",
    "from sklearn.metrics import confusion_matrix\n",
    "cm = confusion_matrix(y_test_class, y_pred_class)\n",
    "import seaborn as sns\n",
    "sns.heatmap(cm,annot=True)\n",
    "plt.savefig('h1.png')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "# Calculate the Accuracy\n",
    "from sklearn.metrics import accuracy_score\n",
    "score=accuracy_score(y_pred_class,y_test_class)\n",
    "score"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "model.save('traffic_classifier.h5')"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Build the Simple App Using Tkinter"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "import tkinter as tk\n",
    "from tkinter import filedialog\n",
    "from tkinter import *\n",
    "from PIL import ImageTk, Image\n",
    "\n",
    "import numpy\n",
    "#load the trained model to classify sign\n",
    "from keras.models import load_model\n",
    "model = load_model('traffic_classifier.h5')\n",
    "\n",
    "#dictionary to label all traffic signs class.\n",
    "classes = { 1:'Speed limit (20km/h)',\n",
    "            2:'Speed limit (30km/h)', \n",
    "            3:'Speed limit (50km/h)', \n",
    "            4:'Speed limit (60km/h)', \n",
    "            5:'Speed limit (70km/h)', \n",
    "            6:'Speed limit (80km/h)', \n",
    "            7:'End of speed limit (80km/h)', \n",
    "            8:'Speed limit (100km/h)', \n",
    "            9:'Speed limit (120km/h)', \n",
    "            10:'No passing', \n",
    "            11:'No passing veh over 3.5 tons', \n",
    "            12:'Right-of-way at intersection', \n",
    "            13:'Priority road', \n",
    "            14:'Yield', \n",
    "            15:'Stop', \n",
    "            16:'No vehicles', \n",
    "            17:'Veh > 3.5 tons prohibited', \n",
    "            18:'No entry', \n",
    "            19:'General caution', \n",
    "            20:'Dangerous curve left', \n",
    "            21:'Dangerous curve right', \n",
    "            22:'Double curve', \n",
    "            23:'Bumpy road', \n",
    "            24:'Slippery road', \n",
    "            25:'Road narrows on the right', \n",
    "            26:'Road work', \n",
    "            27:'Traffic signals', \n",
    "            28:'Pedestrians', \n",
    "            29:'Children crossing', \n",
    "            30:'Bicycles crossing', \n",
    "            31:'Beware of ice/snow',\n",
    "            32:'Wild animals crossing', \n",
    "            33:'End speed + passing limits', \n",
    "            34:'Turn right ahead', \n",
    "            35:'Turn left ahead', \n",
    "            36:'Ahead only', \n",
    "            37:'Go straight or right', \n",
    "            38:'Go straight or left', \n",
    "            39:'Keep right', \n",
    "            40:'Keep left', \n",
    "            41:'Roundabout mandatory', \n",
    "            42:'End of no passing', \n",
    "            43:'End no passing veh > 3.5 tons' }\n",
    "\n",
    "#initialise GUI\n",
    "top=tk.Tk()\n",
    "top.geometry('800x600')\n",
    "top.title('Traffic sign classification')\n",
    "top.configure(background='#CDCDCD')\n",
    "\n",
    "label=Label(top,background='#CDCDCD', font=('arial',15,'bold'))\n",
    "sign_image = Label(top)\n",
    "\n",
    "def classify(file_path):\n",
    "    global label_packed\n",
    "    image = Image.open(file_path)\n",
    "    image = image.resize((30,30))\n",
    "    image = numpy.expand_dims(image, axis=0)\n",
    "    image = numpy.array(image)\n",
    "    pred = model.predict_classes([image])[0]\n",
    "    sign = classes[pred+1]\n",
    "    print(sign)\n",
    "    label.configure(foreground='#011638', text=sign) \n",
    "\n",
    "def show_classify_button(file_path):\n",
    "    classify_b=Button(top,text=\"Classify Image\",command=lambda: classify(file_path),padx=10,pady=5)\n",
    "    classify_b.configure(background='#364156', foreground='white',font=('arial',10,'bold'))\n",
    "    classify_b.place(relx=0.79,rely=0.46)\n",
    "\n",
    "def upload_image():\n",
    "    try:\n",
    "        file_path=filedialog.askopenfilename()\n",
    "        uploaded=Image.open(file_path)\n",
    "        uploaded.thumbnail(((top.winfo_width()/4.25),(top.winfo_height()/4.25)))\n",
    "        im=ImageTk.PhotoImage(uploaded)\n",
    "\n",
    "        sign_image.configure(image=im)\n",
    "        sign_image.image=im\n",
    "        label.configure(text='')\n",
    "        show_classify_button(file_path)\n",
    "    except:\n",
    "        pass\n",
    "\n",
    "upload=Button(top,text=\"Upload an image\",command=upload_image,padx=30,pady=10)\n",
    "upload.configure(background='#364156', foreground='white',font=('arial',10,'bold'))\n",
    "\n",
    "upload.pack(side=BOTTOM,pady=50)\n",
    "sign_image.pack(side=BOTTOM,expand=True)\n",
    "label.pack(side=BOTTOM,expand=True)\n",
    "heading = Label(top, text=\"Know Your Traffic Sign\",pady=20, font=('arial',20,'bold'))\n",
    "heading.configure(background='#CDCDCD',foreground='#364156')\n",
    "heading.pack()\n",
    "top.mainloop()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.2"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
